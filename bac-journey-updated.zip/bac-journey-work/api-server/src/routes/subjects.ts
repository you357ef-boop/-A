import { Router, type IRouter } from "express";

const router: IRouter = Router();

const subjectsByTrack: Record<string, string[]> = {
  engineering: [
    "اللغة العربية",
    "اللغة الإنجليزية",
    "التاريخ الوطني",
    "الكيمياء",
    "البرمجة",
  ],
  medicine: [
    "اللغة العربية",
    "اللغة الإنجليزية",
    "التاريخ الوطني",
    "الفيزياء",
    "الرياضيات",
  ],
  arts: [
    "اللغة العربية",
    "اللغة الإنجليزية",
    "التاريخ الوطني",
    "علم النفس",
    "اللغة الأجنبية الثانية",
  ],
  business: [
    "اللغة العربية",
    "اللغة الإنجليزية",
    "التاريخ الوطني",
    "المحاسبة",
    "إدارة الأعمال",
  ],
};

router.get("/subjects", (request, response) => {
  const trackId = String(request.query.trackId ?? "");

  const subjects = subjectsByTrack[trackId];

  if (!subjects) {
    response.status(404).json({
      error: "المسار غير موجود.",
    });
    return;
  }

  response.json({
    trackId,
    subjects,
  });
});

export default router;
