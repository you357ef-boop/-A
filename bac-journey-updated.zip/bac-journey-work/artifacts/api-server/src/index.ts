import app from "./app";
import { logger } from "./lib/logger";
import { ensureInitialAdmin } from "./routes/auth";
import { ensureAcademicData } from "./routes/subjects";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

async function startServer() {
  try {
    await ensureInitialAdmin();
    await ensureAcademicData();
    app.listen(port, (err) => {
      if (err) {
        logger.error({ err }, "Error listening on port");
        process.exit(1);
      }

      logger.info({ port }, "Server listening");
    });
  } catch (error) {
    logger.error({ err: error }, "API startup failed");
    process.exit(1);
  }
}

void startServer();
