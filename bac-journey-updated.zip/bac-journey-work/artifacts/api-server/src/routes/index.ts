import { Router, type IRouter } from "express";
import authRouter from "./auth";
import healthRouter from "./health";
import subjectsRouter from "./subjects";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(subjectsRouter);

export default router;
