import { randomUUID } from "node:crypto";
import { asc, eq, inArray } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  bacSubjects,
  bacTrackSubjects,
  bacTracks,
  db,
} from "@workspace/db";
import { authenticate, requireAdmin } from "./auth";

const router: IRouter = Router();

const initialTracks = [
  { id: "track_eng", name: "مسار الهندسة", sortOrder: 1 },
  { id: "track_med", name: "مسار الطب وعلوم الحياة", sortOrder: 2 },
  { id: "track_arts", name: "مسار الآداب والفنون", sortOrder: 3 },
  {
    id: "track_bus",
    name: "مسار المحاسبة وإدارة الأعمال",
    sortOrder: 4,
  },
] as const;

const initialSubjects = [
  { id: "subj_arabic", name: "اللغة العربية", isCommon: true, sortOrder: 1 },
  { id: "subj_english", name: "اللغة الإنجليزية", isCommon: true, sortOrder: 2 },
  { id: "subj_history", name: "التاريخ الوطني", isCommon: true, sortOrder: 3 },
  { id: "subj_chem", name: "الكيمياء", isCommon: false, sortOrder: 4 },
  { id: "subj_prog", name: "البرمجة", isCommon: false, sortOrder: 5 },
  { id: "subj_phys", name: "الفيزياء", isCommon: false, sortOrder: 6 },
  { id: "subj_math", name: "الرياضيات", isCommon: false, sortOrder: 7 },
  { id: "subj_lang2", name: "اللغة الثانية", isCommon: false, sortOrder: 8 },
  { id: "subj_psych", name: "علم النفس", isCommon: false, sortOrder: 9 },
  { id: "subj_acc", name: "المحاسبة", isCommon: false, sortOrder: 10 },
  {
    id: "subj_mgmt",
    name: "إدارة الأعمال",
    isCommon: false,
    sortOrder: 11,
  },
] as const;

const subjectsByTrack: Record<string, readonly string[]> = {
  track_eng: ["subj_chem", "subj_prog"],
  track_med: ["subj_phys", "subj_math"],
  track_arts: ["subj_lang2", "subj_psych"],
  track_bus: ["subj_acc", "subj_mgmt"],
};

/** Inserts the existing curriculum once, without overwriting later admin edits. */
export async function ensureAcademicData(): Promise<void> {
  const [existingTrack] = await db
    .select({ id: bacTracks.id })
    .from(bacTracks)
    .limit(1);
  if (existingTrack) return;

  await db.transaction(async (transaction) => {
    for (const track of initialTracks) {
      await transaction.insert(bacTracks).values(track).onConflictDoNothing();
    }
    for (const subject of initialSubjects) {
      await transaction
        .insert(bacSubjects)
        .values(subject)
        .onConflictDoNothing();
    }

    for (const [trackId, subjectIds] of Object.entries(subjectsByTrack)) {
      for (const subjectId of subjectIds) {
        await transaction
          .insert(bacTrackSubjects)
          .values({ trackId, subjectId })
          .onConflictDoNothing();
      }
    }
  });
}

async function getTracksWithSubjects() {
  const [tracks, subjects, links] = await Promise.all([
    db.select().from(bacTracks).orderBy(asc(bacTracks.sortOrder), asc(bacTracks.name)),
    db
      .select()
      .from(bacSubjects)
      .orderBy(asc(bacSubjects.sortOrder), asc(bacSubjects.name)),
    db.select().from(bacTrackSubjects),
  ]);
  const subjectTrackIds = new Map<string, Set<string>>();
  for (const link of links) {
    const trackIds = subjectTrackIds.get(link.subjectId) ?? new Set<string>();
    trackIds.add(link.trackId);
    subjectTrackIds.set(link.subjectId, trackIds);
  }

  return tracks.map((track) => ({
    id: track.id,
    name: track.name,
    subjects: subjects
      .filter(
        (subject) =>
          subject.isCommon ||
          subjectTrackIds.get(subject.id)?.has(track.id) === true,
      )
      .map((subject) => ({
        id: subject.id,
        name: subject.name,
        isCommon: subject.isCommon,
      })),
  }));
}

function parseSubjectInput(body: unknown):
  | { ok: true; name: string; isCommon: boolean; trackIds: string[] }
  | { ok: false; error: string } {
  if (!body || typeof body !== "object") {
    return { ok: false, error: "أدخل بيانات المادة." };
  }
  const value = body as Record<string, unknown>;
  const name =
    typeof value.name === "string" ? value.name.trim().slice(0, 120) : "";
  if (!name) return { ok: false, error: "اسم المادة مطلوب." };

  const isCommon = value.isCommon === true;
  if (value.isCommon !== undefined && typeof value.isCommon !== "boolean") {
    return { ok: false, error: "تحقق من اختيار نوع المادة." };
  }
  const rawTrackIds = value.trackIds ?? [];
  if (
    !Array.isArray(rawTrackIds) ||
    rawTrackIds.length > initialTracks.length ||
    rawTrackIds.some(
      (trackId) => typeof trackId !== "string" || trackId.length > 120,
    )
  ) {
    return { ok: false, error: "تحقق من المسارات المحددة للمادة." };
  }
  const trackIds = [...new Set(rawTrackIds as string[])];
  if (!isCommon && trackIds.length === 0) {
    return { ok: false, error: "اختر مسارًا واحدًا على الأقل للمادة." };
  }
  return { ok: true, name, isCommon, trackIds };
}

async function validateTrackIds(trackIds: string[]): Promise<boolean> {
  if (!trackIds.length) return true;
  const matches = await db
    .select({ id: bacTracks.id })
    .from(bacTracks)
    .where(inArray(bacTracks.id, trackIds));
  return matches.length === trackIds.length;
}

router.get("/tracks", async (_request, response, next) => {
  try {
    response.json({ tracks: await getTracksWithSubjects() });
  } catch (error) {
    next(error);
  }
});

router.get("/subjects", async (request, response, next) => {
  try {
    const trackId = String(request.query.trackId ?? "");
    if (!trackId) {
      response.status(400).json({ error: "حدد المسار الدراسي." });
      return;
    }
    const track = (await getTracksWithSubjects()).find(
      (candidate) => candidate.id === trackId,
    );
    if (!track) {
      response.status(404).json({ error: "المسار غير موجود." });
      return;
    }
    response.json({ trackId, subjects: track.subjects });
  } catch (error) {
    next(error);
  }
});

router.post(
  "/admin/subjects",
  authenticate,
  requireAdmin,
  async (request, response, next) => {
    try {
      const input = parseSubjectInput(request.body);
      if (!input.ok) {
        response.status(400).json({ error: input.error });
        return;
      }
      if (!input.isCommon && !(await validateTrackIds(input.trackIds))) {
        response.status(400).json({ error: "أحد المسارات المحددة غير موجود." });
        return;
      }

      const id = `subj_${randomUUID()}`;
      await db.transaction(async (transaction) => {
        await transaction.insert(bacSubjects).values({
          id,
          name: input.name,
          isCommon: input.isCommon,
        });
        if (!input.isCommon) {
          await transaction
            .insert(bacTrackSubjects)
            .values(input.trackIds.map((trackId) => ({ trackId, subjectId: id })));
        }
      });
      response.status(201).json({ subject: { id, name: input.name, isCommon: input.isCommon } });
    } catch (error) {
      next(error);
    }
  },
);

router.patch(
  "/admin/subjects/:id",
  authenticate,
  requireAdmin,
  async (request, response, next) => {
    try {
      const input = parseSubjectInput(request.body);
      if (!input.ok) {
        response.status(400).json({ error: input.error });
        return;
      }
      if (!input.isCommon && !(await validateTrackIds(input.trackIds))) {
        response.status(400).json({ error: "أحد المسارات المحددة غير موجود." });
        return;
      }

      const subjectId = String(request.params.id);
      const subject = await db.transaction(async (transaction) => {
        const [updated] = await transaction
          .update(bacSubjects)
          .set({ name: input.name, isCommon: input.isCommon })
          .where(eq(bacSubjects.id, subjectId))
          .returning({
            id: bacSubjects.id,
            name: bacSubjects.name,
            isCommon: bacSubjects.isCommon,
          });
        if (!updated) return undefined;

        await transaction
          .delete(bacTrackSubjects)
          .where(eq(bacTrackSubjects.subjectId, subjectId));
        if (!input.isCommon) {
          await transaction
            .insert(bacTrackSubjects)
            .values(
              input.trackIds.map((trackId) => ({
                trackId,
                subjectId,
              })),
            );
        }
        return updated;
      });
      if (!subject) {
        response.status(404).json({ error: "لم يتم العثور على المادة." });
        return;
      }
      response.json({ subject });
    } catch (error) {
      next(error);
    }
  },
);

router.delete(
  "/admin/subjects/:id",
  authenticate,
  requireAdmin,
  async (request, response, next) => {
    try {
      const [deleted] = await db
        .delete(bacSubjects)
        .where(eq(bacSubjects.id, String(request.params.id)))
        .returning({ id: bacSubjects.id });
      if (!deleted) {
        response.status(404).json({ error: "لم يتم العثور على المادة." });
        return;
      }
      response.status(204).end();
    } catch (error) {
      next(error);
    }
  },
);

export default router;
