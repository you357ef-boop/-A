import {
  createHmac,
  randomBytes,
  randomUUID,
  scrypt as scryptCallback,
  timingSafeEqual,
} from "node:crypto";
import { and, desc, eq, gt } from "drizzle-orm";
import { Router, type IRouter, type NextFunction, type Request, type Response } from "express";
import { bacSessions, bacUsers, db } from "@workspace/db";

const router: IRouter = Router();
const COOKIE_NAME = "bac_session";
const SESSION_TTL_MS = 14 * 24 * 60 * 60 * 1000;
const AVATAR_LIMIT = 1_400_000;

type PublicUser = {
  id: string;
  name: string;
  email: string;
  role: string;
  trackId: string | null;
  avatar: string | null;
  active: boolean;
  createdAt: Date;
};

function publicUser(user: typeof bacUsers.$inferSelect): PublicUser {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    trackId: user.trackId,
    avatar: user.avatar,
    active: user.active,
    createdAt: user.createdAt,
  };
}

function text(value: unknown, maxLength: number): string | null {
  return typeof value === "string" &&
    value.trim().length > 0 &&
    value.length <= maxLength
    ? value.trim()
    : null;
}

function normalizedEmail(value: unknown): string | null {
  const email = text(value, 254)?.toLowerCase();
  return email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? email : null;
}

function avatarValue(value: unknown): string | null | undefined {
  if (value === undefined || value === null || value === "") return null;
  if (
    typeof value !== "string" ||
    !value.startsWith("data:image/") ||
    value.length > AVATAR_LIMIT
  ) {
    return undefined;
  }
  return value;
}

function hashSessionToken(token: string): string {
  const secret = process.env.SESSION_SECRET;
  if (!secret) throw new Error("SESSION_SECRET is required by the API server.");
  return createHmac("sha256", secret).update(token).digest("hex");
}

function derivePassword(password: string, salt: string): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    scryptCallback(password, salt, 64, (error, derivedKey) => {
      if (error) reject(error);
      else resolve(derivedKey);
    });
  });
}

async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const derived = await derivePassword(password, salt);
  return `scrypt$${salt}$${derived.toString("hex")}`;
}

async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const [algorithm, salt, hash] = stored.split("$");
  if (algorithm !== "scrypt" || !salt || !hash) return false;
  const expected = Buffer.from(hash, "hex");
  const actual = await derivePassword(password, salt);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

async function issueSession(
  user: typeof bacUsers.$inferSelect,
  response: Response,
): Promise<void> {
  const token = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + SESSION_TTL_MS);
  await db.insert(bacSessions).values({
    tokenHash: hashSessionToken(token),
    userId: user.id,
    expiresAt,
  });
  response.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    path: "/api",
    maxAge: SESSION_TTL_MS,
  });
}

export async function authenticate(
  request: Request,
  response: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const token = request.cookies?.[COOKIE_NAME];
    if (typeof token !== "string" || !token) {
      response.status(401).json({ error: "يلزم تسجيل الدخول." });
      return;
    }
    const [user] = await db
      .select({
        id: bacUsers.id,
        name: bacUsers.name,
        email: bacUsers.email,
        role: bacUsers.role,
        trackId: bacUsers.trackId,
        avatar: bacUsers.avatar,
        active: bacUsers.active,
        createdAt: bacUsers.createdAt,
      })
      .from(bacSessions)
      .innerJoin(bacUsers, eq(bacSessions.userId, bacUsers.id))
      .where(
        and(
          eq(bacSessions.tokenHash, hashSessionToken(token)),
          gt(bacSessions.expiresAt, new Date()),
          eq(bacUsers.active, true),
        ),
      )
      .limit(1);
    if (!user) {
      response.status(401).json({ error: "انتهت الجلسة. سجّل الدخول مجددًا." });
      return;
    }
    response.locals.authUser = user as PublicUser;
    next();
  } catch (error) {
    next(error);
  }
}

export function requireAdmin(
  _request: Request,
  response: Response,
  next: NextFunction,
): void {
  const user = response.locals.authUser as PublicUser | undefined;
  if (!user) {
    response.status(401).json({ error: "يلزم تسجيل الدخول." });
    return;
  }
  if (user.role !== "admin") {
    response.status(403).json({ error: "هذه العملية متاحة للمدير فقط." });
    return;
  }
  next();
}

router.post("/auth/register", async (request, response, next) => {
  try {
    const body = request.body as Record<string, unknown>;
    const name = text(body.name, 120);
    const email = normalizedEmail(body.email);
    const password = typeof body.password === "string" ? body.password : "";
    const trackId = text(body.trackId, 120);
    const avatar = avatarValue(body.avatar);
    if (!name || !email || !trackId || avatar === undefined) {
      response.status(400).json({ error: "تحقق من بيانات التسجيل وحاول مجددًا." });
      return;
    }
    if (password.length < 8 || password.length > 256) {
      response.status(400).json({ error: "يجب أن تتكون كلمة المرور من 8 خانات على الأقل." });
      return;
    }
    const passwordHash = await hashPassword(password);
    const [user] = await db
      .insert(bacUsers)
      .values({
        id: randomUUID(),
        name,
        email,
        passwordHash,
        role: "student",
        trackId,
        avatar,
      })
      .returning();
    response.status(201).json({ user: publicUser(user) });
  } catch (error) {
    if ((error as { code?: string })?.code === "23505") {
      response.status(409).json({ error: "هذا البريد مسجل بالفعل." });
      return;
    }
    next(error);
  }
});

router.post("/auth/migrate-student", async (request, response, next) => {
  try {
    const body = request.body as Record<string, unknown>;
    const name = text(body.name, 120);
    const email = normalizedEmail(body.email);
    const password = typeof body.password === "string" ? body.password : "";
    const trackId = text(body.trackId, 120);
    const oldId = text(body.id, 120);
    const avatar = avatarValue(body.avatar);
    if (!name || !email || !password || password.length > 256 || !trackId || avatar === undefined) {
      response.status(400).json({ error: "تعذر نقل بيانات الحساب القديم." });
      return;
    }
    const [user] = await db
      .insert(bacUsers)
      .values({
        id: oldId && /^std_[a-zA-Z0-9_-]{6,110}$/.test(oldId) ? oldId : randomUUID(),
        name,
        email,
        passwordHash: await hashPassword(password),
        role: "student",
        trackId,
        avatar,
      })
      .returning();
    await issueSession(user, response);
    response.status(200).json({ user: publicUser(user), migrated: true });
  } catch (error) {
    if ((error as { code?: string })?.code === "23505") {
      response.status(409).json({
        error: "هذا البريد مسجل على الخادم بالفعل. سجّل الدخول بكلمة مرور الحساب الموجودة هناك.",
      });
      return;
    }
    next(error);
  }
});

router.post("/auth/login", async (request, response, next) => {
  try {
    const body = request.body as Record<string, unknown>;
    const identifier = text(body.email, 254);
    const email = normalizedEmail(identifier);
    const password = typeof body.password === "string" ? body.password : "";
    if (!identifier || !password || password.length > 256) {
      response.status(401).json({ error: "بيانات الدخول غير صحيحة." });
      return;
    }
    const matches = await db
      .select()
      .from(bacUsers)
      .where(
        and(
          email ? eq(bacUsers.email, email) : eq(bacUsers.name, identifier),
          eq(bacUsers.active, true),
        ),
      )
      .limit(2);
    const user = matches.length === 1 ? matches[0] : undefined;
    if (!user || !(await verifyPassword(password, user.passwordHash))) {
      response.status(401).json({ error: "بيانات الدخول غير صحيحة." });
      return;
    }
    await issueSession(user, response);
    response.json({ user: publicUser(user) });
  } catch (error) {
    next(error);
  }
});

router.get("/auth/me", authenticate, (_request, response) => {
  response.json({ user: response.locals.authUser as PublicUser });
});

router.post("/auth/logout", async (request, response, next) => {
  try {
    const token = request.cookies?.[COOKIE_NAME];
    if (typeof token === "string" && token) {
      await db
        .delete(bacSessions)
        .where(eq(bacSessions.tokenHash, hashSessionToken(token)));
    }
    response.clearCookie(COOKIE_NAME, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      path: "/api",
    });
    response.status(204).end();
  } catch (error) {
    next(error);
  }
});

router.get(
  "/admin/students",
  authenticate,
  requireAdmin,
  async (_request, response, next) => {
    try {
      const students = await db
        .select()
        .from(bacUsers)
        .where(and(eq(bacUsers.role, "student"), eq(bacUsers.active, true)))
        .orderBy(desc(bacUsers.createdAt));
      response.json({ students: students.map(publicUser) });
    } catch (error) {
      next(error);
    }
  },
);

router.delete(
  "/admin/students/:id",
  authenticate,
  requireAdmin,
  async (request, response, next) => {
    try {
      const studentId = String(request.params.id ?? "");
      const [student] = await db
        .update(bacUsers)
        .set({ active: false })
        .where(
          and(
            eq(bacUsers.id, studentId),
            eq(bacUsers.role, "student"),
            eq(bacUsers.active, true),
          ),
        )
        .returning({ id: bacUsers.id });
      if (!student) {
        response.status(404).json({ error: "لم يتم العثور على الطالب." });
        return;
      }
      await db
        .delete(bacSessions)
        .where(eq(bacSessions.userId, student.id));
      response.status(204).end();
    } catch (error) {
      next(error);
    }
  },
);

export async function ensureInitialAdmin(): Promise<void> {
  const email = normalizedEmail(process.env.BAC_ADMIN_EMAIL);
  const password = process.env.BAC_ADMIN_PASSWORD;
  if (!email) {
    throw new Error(
      "BAC_ADMIN_EMAIL is missing or does not contain a valid email address.",
    );
  }
  if (!password) {
    throw new Error("BAC_ADMIN_PASSWORD is missing.");
  }
  if (password.length < 8) {
    throw new Error("BAC_ADMIN_PASSWORD must be at least 8 characters.");
  }

  const admins = await db
    .select({
      id: bacUsers.id,
      email: bacUsers.email,
      passwordHash: bacUsers.passwordHash,
    })
    .from(bacUsers)
    .where(eq(bacUsers.role, "admin"))
    .limit(2);

  if (admins.length > 1) {
    const matchingAdmin = admins.find((admin) => admin.email === email);
    if (!matchingAdmin) {
      throw new Error(
        "Multiple administrator accounts exist; the configured email must identify the account to update.",
      );
    }
    if (await verifyPassword(password, matchingAdmin.passwordHash)) return;
    await db
      .update(bacUsers)
      .set({ passwordHash: await hashPassword(password), active: true })
      .where(eq(bacUsers.id, matchingAdmin.id));
    await db
      .delete(bacSessions)
      .where(eq(bacSessions.userId, matchingAdmin.id));
    return;
  }

  const [existingUser] = await db
    .select({ id: bacUsers.id, role: bacUsers.role })
    .from(bacUsers)
    .where(eq(bacUsers.email, email))
    .limit(1);

  if (admins.length === 1) {
    const existingAdmin = admins[0];
    if (existingUser && existingUser.id !== existingAdmin.id) {
      throw new Error(
        "The configured administrator email is already assigned to a different account.",
      );
    }
    if (
      existingAdmin.email === email &&
      (await verifyPassword(password, existingAdmin.passwordHash))
    ) {
      return;
    }

    await db
      .update(bacUsers)
      .set({
        name: "مدير المنصة",
        email,
        passwordHash: await hashPassword(password),
        active: true,
      })
      .where(eq(bacUsers.id, existingAdmin.id));
    await db
      .delete(bacSessions)
      .where(eq(bacSessions.userId, existingAdmin.id));
    return;
  }

  if (existingUser) {
    throw new Error(
      "The configured administrator email is already assigned to a non-admin account.",
    );
  }

  await db.insert(bacUsers).values({
    id: randomUUID(),
    name: "مدير المنصة",
    email,
    passwordHash: await hashPassword(password),
    role: "admin",
    trackId: null,
    avatar: null,
  });
}

export default router;
