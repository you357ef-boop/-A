import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { FormEvent, ReactNode } from "react";
import type * as React from "react";
import {
  BookOpen,
  GraduationCap,
  LayoutDashboard,
  Users,
  Route as RouteIcon,
  FolderOpen,
  ClipboardCheck,
  Headset,
  Megaphone,
  LogOut,
  Bell,
  Menu,
  Moon,
  X,
  Plus,
  Search,
  FileText,
  Award,
  Clock3,
  ArrowUpLeft,
  Send,
  Trash2,
  MessageCircle,
  Video,
  Download,
  ChevronLeft,
  CalendarDays,
  Sun,
  Pencil,
} from "lucide-react";

type Row = Record<string, any>;
type AppTheme = "light" | "dark";
class ApiError extends Error {
  constructor(
    message: string,
    readonly status: number,
  ) {
    super(message);
  }
}

async function requestApi<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(`/api${path}`, {
    ...init,
    credentials: "same-origin",
    headers: {
      ...(init.body ? { "Content-Type": "application/json" } : {}),
      ...init.headers,
    },
  });
  const payload =
    response.status === 204
      ? null
      : await response.json().catch(() => null);
  if (!response.ok) {
    throw new ApiError(
      typeof payload?.error === "string"
        ? payload.error
        : "تعذر إكمال الطلب. حاول مرة أخرى.",
      response.status,
    );
  }
  return payload as T;
}

function fileToDataUrl(file: unknown): Promise<string | null> {
  if (!(file instanceof Blob) || file.size === 0) return Promise.resolve(null);
  if (!file.type.startsWith("image/") || file.size > 1_000_000) {
    return Promise.reject(
      new Error("يجب أن تكون الصورة أقل من 1 ميجابايت."),
    );
  }
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () =>
      resolve(typeof reader.result === "string" ? reader.result : null);
    reader.onerror = () =>
      reject(reader.error ?? new Error("تعذر قراءة الصورة."));
    reader.readAsDataURL(file);
  });
}

type StoreName =
  | "users"
  | "tracks"
  | "content"
  | "exams"
  | "results"
  | "notifications"
  | "tickets"
  | "messages";
const DB_NAME = "BacJourneyDB";
let db: IDBDatabase | null = null;
const stores: StoreName[] = [
  "users",
  "tracks",
  "content",
  "exams",
  "results",
  "notifications",
  "tickets",
  "messages",
];
const openDb = () =>
  new Promise<IDBDatabase>((resolve, reject) => {
    const r = indexedDB.open(DB_NAME, 1);
    r.onerror = () => reject(r.error);
    r.onupgradeneeded = () => {
      const d = r.result;
      if (!d.objectStoreNames.contains("users")) {
        const s = d.createObjectStore("users", { keyPath: "id" });
        s.createIndex("email", "email", { unique: true });
        s.createIndex("role", "role");
      }
      if (!d.objectStoreNames.contains("tracks"))
        d.createObjectStore("tracks", { keyPath: "id" });
      if (!d.objectStoreNames.contains("content")) {
        const s = d.createObjectStore("content", { keyPath: "id" });
        s.createIndex("trackId", "trackId");
        s.createIndex("subjectId", "subjectId");
      }
      if (!d.objectStoreNames.contains("exams")) {
        const s = d.createObjectStore("exams", { keyPath: "id" });
        s.createIndex("trackId", "trackId");
      }
      if (!d.objectStoreNames.contains("results")) {
        const s = d.createObjectStore("results", { keyPath: "id" });
        s.createIndex("studentId", "studentId");
      }
      if (!d.objectStoreNames.contains("notifications")) {
        const s = d.createObjectStore("notifications", { keyPath: "id" });
        s.createIndex("targetTrack", "targetTrack");
      }
      if (!d.objectStoreNames.contains("tickets")) {
        const s = d.createObjectStore("tickets", { keyPath: "id" });
        s.createIndex("studentId", "studentId");
      }
      if (!d.objectStoreNames.contains("messages")) {
        const s = d.createObjectStore("messages", { keyPath: "id" });
        s.createIndex("ticketId", "ticketId");
      }
    };
    r.onsuccess = () => resolve(r.result);
  });
const getAll = (store: StoreName) =>
  new Promise<Row[]>((resolve, reject) => {
    if (!db) return reject(Error("قاعدة البيانات غير جاهزة"));
    const r = db.transaction(store, "readonly").objectStore(store).getAll();
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
const getOne = (store: StoreName, id: string) =>
  new Promise<Row | undefined>((resolve, reject) => {
    const r = db!.transaction(store, "readonly").objectStore(store).get(id);
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
const put = (store: StoreName, item: Row) =>
  new Promise<void>((resolve, reject) => {
    const r = db!.transaction(store, "readwrite").objectStore(store).put(item);
    r.onsuccess = () => resolve();
    r.onerror = () => reject(r.error);
  });
const add = (store: StoreName, item: Row) =>
  new Promise<void>((resolve, reject) => {
    const r = db!.transaction(store, "readwrite").objectStore(store).add(item);
    r.onsuccess = () => resolve();
    r.onerror = () => reject(r.error);
  });
const del = (store: StoreName, id: string) =>
  new Promise<void>((resolve, reject) => {
    const r = db!.transaction(store, "readwrite").objectStore(store).delete(id);
    r.onsuccess = () => resolve();
    r.onerror = () => reject(r.error);
  });
const id = (prefix: string) =>
  `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
const date = (d?: string) =>
  d
    ? new Date(d).toLocaleDateString("ar-EG", {
        year: "numeric",
        month: "short",
        day: "numeric",
      })
    : "—";
const typeLabel = (t: string) =>
  (({ lesson: "درس", pdf: "ملف", video: "فيديو", note: "ملخص" }) as Row)[t] ||
  t;
const statusClass = (s: string) =>
  s === "جديدة"
    ? "badge-red"
    : s === "قيد المراجعة"
      ? "badge-amber"
      : s === "تم الرد"
        ? "badge-green"
        : "badge-blue";
const navStudent: [string, string, any][] = [
  ["overview", "نظرة عامة", LayoutDashboard],
  ["subjects", "موادي الدراسية", BookOpen],
  ["exams", "الامتحانات والنتائج", ClipboardCheck],
  ["support", "الدعم الفني", Headset],
];
const navAdmin: [string, string, any][] = [
  ["overview", "الرئيسية", LayoutDashboard],
  ["students", "إدارة الطلاب", Users],
  ["tracks", "المسارات والمواد", RouteIcon],
  ["content", "إدارة المحتوى", FolderOpen],
  ["examsAdmin", "إدارة الامتحانات", ClipboardCheck],
  ["supportAdmin", "فريق الدعم", Headset],
  ["notices", "الإشعارات", Megaphone],
];

function App() {
  const [theme, setTheme] = useState<AppTheme>(() => {
    try {
      const saved = localStorage.getItem("bac-journey-theme");
      return saved === "dark" || saved === "light" ? saved : "light";
    } catch {
      return "light";
    }
  });
  const [ready, setReady] = useState(false),
    [error, setError] = useState(""),
    [data, setData] = useState<Record<StoreName, Row[]>>({
      users: [],
      tracks: [],
      content: [],
      exams: [],
      results: [],
      notifications: [],
      tickets: [],
      messages: [],
    });
  const submitExamRef = useRef<() => Promise<void>>(async () => {});
  const [user, setUser] = useState<Row | null>(null),
    [view, setView] = useState("overview"),
    [authTab, setAuthTab] = useState("login"),
    [modal, setModal] = useState<{
      title: string;
      body: (close: () => void) => ReactNode;
    } | null>(null),
    [toast, setToast] = useState(""),
    [query, setQuery] = useState(""),
    [mobile, setMobile] = useState(false),
    [noticeOpen, setNoticeOpen] = useState(false),
    [subjectPick, setSubjectPick] = useState<string | null>(null),
    [examRun, setExamRun] = useState<Row | null>(null),
    [examIdx, setExamIdx] = useState(0),
    [answers, setAnswers] = useState<Record<number, number>>({}),
    [timeLeft, setTimeLeft] = useState(0);
  const currentUserRef = useRef<Row | null>(null);
  currentUserRef.current = user;
  const refresh = useCallback(async (account?: Row | null) => {
    const activeUser = account === undefined ? currentUserRef.current : account;
    const [entries, { tracks }, users] = await Promise.all([
      Promise.all(
        stores
          .filter((store) => store !== "users" && store !== "tracks")
          .map(async (store) => [store, await getAll(store)] as const),
      ),
      requestApi<{ tracks: Row[] }>("/tracks"),
      activeUser?.role === "admin"
        ? requestApi<{ students: Row[] }>("/admin/students").then(
            ({ students }) => students,
          )
        : Promise.resolve(activeUser ? [activeUser] : []),
    ]);
    setData({
      ...Object.fromEntries(entries),
      tracks,
      users,
    } as Record<StoreName, Row[]>);
  }, []);
  useEffect(() => {
    (async () => {
      try {
        db = await openDb();
        sessionStorage.removeItem("bac_logged_user");
        let activeUser: Row | null = null;
        try {
          activeUser = (
            await requestApi<{ user: Row }>("/auth/me")
          ).user;
        } catch (authError) {
          if (!(authError instanceof ApiError) || authError.status !== 401) {
            throw authError;
          }
        }
        setUser(activeUser);
        await refresh(activeUser);
        setReady(true);
      } catch (e) {
        setError(
          "تعذر الاتصال بقاعدة البيانات المشتركة. تحقق من الاتصال ثم أعد المحاولة.",
        );
        setReady(true);
      }
    })();
  }, [refresh]);
  useEffect(() => {
    document.documentElement.lang = "ar";
    document.documentElement.dir = "rtl";
  }, []);
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    document.documentElement.style.colorScheme = theme;
    try {
      localStorage.setItem("bac-journey-theme", theme);
    } catch {
      // The theme still works for this session when storage is unavailable.
    }
  }, [theme]);
  useEffect(() => {
    if (toast) {
      const t = setTimeout(() => setToast(""), 3200);
      return () => clearTimeout(t);
    }
    return undefined;
  }, [toast]);
  const track = user ? data.tracks.find((t) => t.id === user.trackId) : null;
  const title = useMemo(
    () =>
      ({
        overview:
          user?.role === "admin" ? "لوحة التحكم الإدارية" : "لوحة تحكم الطالب",
        subjects: "موادي الدراسية",
        exams: "الامتحانات والنتائج",
        support: "الدعم الفني",
        students: "إدارة الطلاب",
        tracks: "المسارات والمواد",
        content: "إدارة المحتوى التعليمي",
        examsAdmin: "إدارة الامتحانات",
        supportAdmin: "فريق دعم المنصة",
        notices: "إدارة الإشعارات",
      }) as Row,
    [user],
  );
  const flash = (s: string) => setToast(s);
  const toggleTheme = () =>
    setTheme((current) => (current === "light" ? "dark" : "light"));
  const go = (v: string) => {
    setView(v);
    setQuery("");
    setSubjectPick(null);
    setMobile(false);
    setNoticeOpen(false);
  };
  async function login(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget),
      email = String(f.get("email")).toLowerCase().trim(),
      pass = String(f.get("password"));
    try {
      let result: { user: Row };
      try {
        result = await requestApi<{ user: Row }>("/auth/login", {
          method: "POST",
          body: JSON.stringify({ email, password: pass }),
        });
      } catch (error) {
        if (!(error instanceof ApiError) || error.status !== 401) throw error;
        const localUsers = await getAll("users");
        const legacy = localUsers.find(
          (candidate) =>
            candidate.role === "student" &&
            candidate.email?.toLowerCase() === email &&
            candidate.password === pass,
        );
        if (!legacy) throw error;
        const avatar = await fileToDataUrl(legacy.avatar);
        result = await requestApi<{ user: Row }>("/auth/migrate-student", {
          method: "POST",
          body: JSON.stringify({
            id: legacy.id,
            name: legacy.name,
            email: legacy.email,
            password: pass,
            trackId: legacy.trackId,
            avatar,
          }),
        });
        await put("users", { ...legacy, password: "" });
        flash("تم نقل حسابك إلى الحفظ المشترك بنجاح.");
      }
      setUser(result.user);
      await refresh(result.user);
      go("overview");
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) {
        flash(
          "بيانات الدخول غير صحيحة. إذا كان حسابك محفوظًا على جهاز آخر، افتح المنصة من ذلك الجهاز أولًا لمزامنته.",
        );
      } else if (error instanceof Error) {
        flash(error.message);
      } else {
        flash("تعذر الاتصال بالخادم. حاول مرة أخرى.");
      }
    }
  }
  async function register(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget),
      email = String(f.get("email")).toLowerCase().trim();
    try {
      const avatar = await fileToDataUrl(f.get("avatar"));
      await requestApi("/auth/register", {
        method: "POST",
        body: JSON.stringify({
          name: String(f.get("name")).trim(),
          email,
          password: String(f.get("password")),
          trackId: String(f.get("trackId")),
          avatar,
        }),
      });
      setAuthTab("login");
      flash("تم إنشاء الحساب في قاعدة البيانات المشتركة. سجّل الدخول الآن.");
    } catch (error) {
      if (error instanceof Error) flash(error.message);
      else flash("تعذر إنشاء الحساب. حاول مرة أخرى.");
    }
  }
  async function logout() {
    let loggedOut = false;
    try {
      await requestApi("/auth/logout", { method: "POST" });
      loggedOut = true;
    } catch {
      flash("تعذر إنهاء الجلسة على الخادم. تحقق من الاتصال ثم أعد المحاولة.");
    } finally {
      setUser(null);
      setData((current) => ({ ...current, users: [] }));
      go("overview");
      if (loggedOut) flash("تم تسجيل الخروج");
    }
  }
  async function remove(
    store: StoreName,
    key: string,
    msg: string,
    refreshView?: string,
  ) {
    if (!confirm("هل تريد المتابعة؟ لا يمكن التراجع عن هذا الإجراء.")) return;
    if (store === "users") {
      await requestApi(`/admin/students/${encodeURIComponent(key)}`, {
        method: "DELETE",
      });
    } else {
      await del(store, key);
    }
    await refresh();
    flash(msg);
    if (refreshView) go(refreshView);
  }
  function openModal(
    titleText: string,
    body: (close: () => void) => ReactNode,
  ) {
    setModal({ title: titleText, body });
  }
  const close = () => setModal(null);
  async function saveContent(
    e: FormEvent<HTMLFormElement>,
    closeModal: () => void,
  ) {
    e.preventDefault();
    const f = new FormData(e.currentTarget),
      file = f.get("file") as File;
    await add("content", {
      id: id("cnt"),
      title: String(f.get("title")),
      type: String(f.get("type")),
      trackId: String(f.get("trackId")),
      subjectId: String(f.get("subjectId")),
      description: String(f.get("description")),
      blob: file?.size ? file : null,
      url: String(f.get("url") || ""),
      createdAt: new Date().toISOString(),
    });
    await refresh();
    closeModal();
    flash("أُضيف المحتوى بنجاح");
  }
  async function saveSubject(
    subjectId: string | null,
    input: { name: string; trackIds: string[]; isCommon: boolean },
    closeModal: () => void,
  ) {
    try {
      await requestApi(
        subjectId
          ? `/admin/subjects/${encodeURIComponent(subjectId)}`
          : "/admin/subjects",
        {
          method: subjectId ? "PATCH" : "POST",
          body: JSON.stringify(input),
        },
      );
      await refresh();
      closeModal();
      flash(subjectId ? "تم تحديث المادة" : "تمت إضافة المادة");
    } catch (error) {
      flash(error instanceof Error ? error.message : "تعذر حفظ المادة.");
    }
  }
  async function deleteSubject(subject: Row) {
    const scope = subject.isCommon
      ? "ستُحذف المادة المشتركة من جميع المسارات."
      : "لا يمكن التراجع عن حذف المادة.";
    if (!confirm(`هل تريد حذف «${subject.name}»؟ ${scope}`)) return;
    try {
      await requestApi(`/admin/subjects/${encodeURIComponent(subject.id)}`, {
        method: "DELETE",
      });
      await refresh();
      flash("تم حذف المادة");
    } catch (error) {
      flash(error instanceof Error ? error.message : "تعذر حذف المادة.");
    }
  }
  async function saveExam(
    e: FormEvent<HTMLFormElement>,
    closeModal: () => void,
  ) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const texts = f.getAll("questionText[]").map((value) => String(value));
    const points = f.getAll("questionPoints[]").map(Number);
    const optionSets = f.getAll("options[]").map((value) =>
      String(value)
        .split(",")
        .map((option) => option.trim())
        .filter(Boolean),
    );
    const correctIndexes = f.getAll("correctIndex[]").map(Number);
    const questions = texts.map((text, index) => ({
      text: text.trim(),
      points: points[index],
      options: optionSets[index],
      correctIndex: correctIndexes[index],
    }));
    if (
      !questions.length ||
      questions.some(
        (question) =>
          !question.text ||
          question.points <= 0 ||
          question.options.length < 2 ||
          !Number.isInteger(question.correctIndex) ||
          question.correctIndex < 0 ||
          question.correctIndex >= question.options.length,
      )
    ) {
      flash(
        "تحقق من كل سؤال: أدخل خيارين على الأقل وحدد رقم إجابة صحيحة صالحاً",
      );
      return;
    }
    await add("exams", {
      id: id("ex"),
      title: String(f.get("title")),
      duration: Number(f.get("duration")),
      trackId: String(f.get("trackId")),
      questions,
      createdAt: new Date().toISOString(),
    });
    await refresh();
    closeModal();
    flash("تم إنشاء الامتحان");
  }
  async function submitExam() {
    if (!examRun) return;
    const currentUser = user;
    if (!currentUser) return;
    const qs = examRun.questions || [];
    let totalScore = 0,
      obtainedScore = 0;
    qs.forEach((q: Row, i: number) => {
      totalScore += Number(q.points);
      if (answers[i] === Number(q.correctIndex))
        obtainedScore += Number(q.points);
    });
    await add("results", {
      id: id("res"),
      studentId: currentUser.id,
      studentName: currentUser.name,
      examId: examRun.id,
      examTitle: examRun.title,
      totalScore,
      obtainedScore,
      score: Math.round((obtainedScore / totalScore) * 100) || 0,
      date: new Date().toISOString(),
    });
    setExamRun(null);
    await refresh();
    go("exams");
    flash("تم تسليم إجاباتك وتصحيحها تلقائياً");
  }
  submitExamRef.current = submitExam;
  useEffect(() => {
    if (!examRun) return;
    const t = setInterval(
      () =>
        setTimeLeft((s) => {
          if (s <= 1) {
            clearInterval(t);
            void submitExamRef.current();
            return 0;
          }
          return s - 1;
        }),
      1000,
    );
    return () => clearInterval(t);
  }, [examRun]);
  async function createTicket(
    e: FormEvent<HTMLFormElement>,
    closeModal: () => void,
  ) {
    const currentUser = user;
    if (!currentUser) return;
    e.preventDefault();
    const f = new FormData(e.currentTarget),
      ticket = {
        id: id("tkt"),
        studentId: currentUser.id,
        studentName: currentUser.name,
        subject: String(f.get("subject")),
        type: String(f.get("type")),
        status: "جديدة",
        createdAt: new Date().toISOString(),
      };
    await add("tickets", ticket);
    await add("messages", {
      id: id("msg"),
      ticketId: ticket.id,
      senderRole: "student",
      senderName: currentUser.name,
      text: String(f.get("message")),
      createdAt: new Date().toISOString(),
    });
    await refresh();
    closeModal();
    flash("تم إرسال طلبك إلى فريق الدعم");
  }
  async function sendMessage(e: FormEvent<HTMLFormElement>, ticket: Row) {
    const currentUser = user;
    if (!currentUser) return;
    e.preventDefault();
    const form = e.currentTarget,
      f = new FormData(form),
      text = String(f.get("text")).trim();
    if (!text) return;
    await add("messages", {
      id: id("msg"),
      ticketId: ticket.id,
      senderRole: currentUser.role,
      senderName: currentUser.name,
      text,
      createdAt: new Date().toISOString(),
    });
    if (currentUser.role === "admin" && ticket.status === "جديدة")
      await put("tickets", { ...ticket, status: "تم الرد" });
    await refresh();
    form.reset();
  }
  function openChat(ticket: Row) {
    const currentUser = user;
    if (!currentUser) return;
    openModal(`محادثة · ${ticket.subject}`, (closeModal) => (
      <Chat ticket={ticket} data={data} user={currentUser} send={sendMessage} />
    ));
  }
  async function saveNotice(
    e: FormEvent<HTMLFormElement>,
    closeModal: () => void,
  ) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    await add("notifications", {
      id: id("notice"),
      title: String(f.get("title")),
      message: String(f.get("message")),
      targetTrack: String(f.get("targetTrack")),
      createdAt: new Date().toISOString(),
    });
    await refresh();
    closeModal();
    flash("تم إرسال الإعلان للطلاب");
  }
  function subjectContent(subjectId: string) {
    setSubjectPick(subjectId);
    setQuery("");
    setView("subjects");
  }

  if (!ready)
    return (
      <div className="auth-screen">
        <div className="auth-form-wrap">
          <div className="auth-theme-control">
            <ThemeToggle theme={theme} onToggle={toggleTheme} />
          </div>
          <div className="auth-card">
            <div className="stat-icon">
              <GraduationCap />
            </div>
            <h2>تهيئة رحلتك الدراسية</h2>
            <p>نجهز مساحة التعلم المحلية...</p>
            <div className="empty">جارٍ تحميل بيانات المنصة</div>
          </div>
        </div>
      </div>
    );
  if (error)
    return (
      <div className="auth-screen">
        <div className="auth-form-wrap">
          <div className="auth-theme-control">
            <ThemeToggle theme={theme} onToggle={toggleTheme} />
          </div>
          <div className="auth-card">
            <h2>حدثت مشكلة</h2>
            <p>{error}</p>
            <button
              className="btn btn-primary"
              onClick={() => location.reload()}
              data-testid="button-retry"
            >
              إعادة المحاولة
            </button>
          </div>
        </div>
      </div>
    );
  if (!user)
    return (
      <div className="auth-screen" dir="rtl">
        <aside className="auth-aside">
          <div className="brand">
            <span className="brand-mark">
              <GraduationCap size={22} />
            </span>
            <span>
              رحلة البكالوريا<small>معرفة منظمة، وخطوة أوضح</small>
            </span>
          </div>
          <div>
            <div className="eyebrow">مساحتك للتعلّم</div>
            <h1>رحلتك نحو البكالوريا تبدأ بخطوة.</h1>
            <p>اجمع دروسك وامتحاناتك في مكان واحد، وتابع تقدمك بهدوء وثقة.</p>
          </div>
          <div className="auth-aside-foot">
            مسارات دراسية واضحة · محتوى مرتب · دعم قريب
          </div>
        </aside>
        <section className="auth-form-wrap">
          <div className="auth-theme-control">
            <ThemeToggle theme={theme} onToggle={toggleTheme} />
          </div>
          <div className="auth-card">
            <div className="brand" style={{ padding: "0 0 23px", border: 0 }}>
              <span className="brand-mark">
                <GraduationCap size={22} />
              </span>
              <span>
                رحلة البكالوريا<small>منصة التعلّم المدرسي</small>
              </span>
            </div>
            <h2>
              {authTab === "login" ? "مرحباً بعودتك" : "أنشئ حسابك الدراسي"}
            </h2>
            <p>
              {authTab === "login"
                ? "سجّل الدخول لمتابعة رحلتك التعليمية."
                : "خطوة واحدة تفصلك عن تنظيم دراستك."}
            </p>
            <div className="auth-tabs">
              <button
                className={authTab === "login" ? "active" : ""}
                onClick={() => setAuthTab("login")}
                data-testid="tab-login"
              >
                تسجيل الدخول
              </button>
              <button
                className={authTab === "register" ? "active" : ""}
                onClick={() => setAuthTab("register")}
                data-testid="tab-register"
              >
                إنشاء حساب
              </button>
            </div>
            {authTab === "login" ? (
              <form className="form-stack" onSubmit={login}>
                <label>
                  <span className="form-label">
                    البريد الإلكتروني أو اسم المستخدم
                  </span>
                  <input
                    className="field"
                    name="email"
                    autoComplete="username"
                    required
                    placeholder="name@example.com"
                    data-testid="input-login-email"
                  />
                </label>
                <label>
                  <span className="form-label">كلمة المرور</span>
                  <input
                    className="field"
                    name="password"
                    type="password"
                    autoComplete="current-password"
                    required
                    placeholder="أدخل كلمة المرور"
                    data-testid="input-login-password"
                  />
                </label>
                <button
                  className="btn btn-primary"
                  type="submit"
                  data-testid="button-login"
                >
                  دخول إلى المنصة <ArrowUpLeft size={16} />
                </button>
              </form>
            ) : (
              <form className="form-stack" onSubmit={register}>
                <label>
                  <span className="form-label">الاسم الكامل</span>
                  <input
                    className="field"
                    name="name"
                    required
                    placeholder="الاسم الثلاثي"
                    data-testid="input-register-name"
                  />
                </label>
                <label>
                  <span className="form-label">البريد الإلكتروني</span>
                  <input
                    className="field"
                    name="email"
                    type="email"
                    required
                    placeholder="name@example.com"
                    data-testid="input-register-email"
                  />
                </label>
                <label>
                  <span className="form-label">كلمة المرور</span>
                  <input
                    className="field"
                    name="password"
                    type="password"
                    required
                    minLength={8}
                    placeholder="8 خانات على الأقل"
                    data-testid="input-register-password"
                  />
                </label>
                <label>
                  <span className="form-label">المسار الدراسي</span>
                  <select
                    name="trackId"
                    required
                    defaultValue=""
                    data-testid="select-register-track"
                  >
                    <option value="" disabled>
                      اختر مسارك
                    </option>
                    {data.tracks.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name}
                      </option>
                    ))}
                  </select>
                </label>
                <label>
                  <span className="form-label">
                    الصورة الشخصية <span className="hint">(اختياري)</span>
                  </span>
                  <input
                    className="field"
                    name="avatar"
                    type="file"
                    accept="image/*"
                    data-testid="input-register-avatar"
                  />
                </label>
                <button
                  className="btn btn-primary"
                  type="submit"
                  data-testid="button-register"
                >
                  إنشاء الحساب <ArrowUpLeft size={16} />
                </button>
              </form>
            )}
          </div>
        </section>
        {toast && (
          <div className="toast" role="status">
            {toast}
          </div>
        )}
      </div>
    );

  const nav = user.role === "admin" ? navAdmin : navStudent;
  const notifs = data.notifications.filter(
    (n) => n.targetTrack === "all" || n.targetTrack === user.trackId,
  );
  const myContent =
    user.role === "admin"
      ? data.content
      : data.content.filter((c) => c.trackId === user.trackId);
  const myExams =
    user.role === "admin"
      ? data.exams
      : data.exams.filter((x) => x.trackId === user.trackId);
  const myResults = data.results
    .filter((r) => r.studentId === user.id)
    .sort((a, b) => +new Date(b.date) - +new Date(a.date));
  const myTickets = data.tickets
    .filter((t) => user.role === "admin" || t.studentId === user.id)
    .sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
  const recentContent = [...myContent]
    .sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt))
    .slice(0, 4);
  const recentTickets = [...data.tickets]
    .sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt))
    .slice(0, 4);
  const allMenu = () => (
    <>
      <div className="nav-label">
        {user.role === "admin" ? "إدارة المنصة" : "مساحة الطالب"}
      </div>
      {nav.map(([key, label, Icon]) => (
        <button
          key={key}
          className={view === key ? "active" : ""}
          onClick={() => go(key)}
          data-testid={`nav-${key}`}
        >
          <Icon size={17} />
          <span>{label}</span>
          {key === "supportAdmin" &&
            data.tickets.filter((t) => t.status === "جديدة").length > 0 && (
              <span className="badge badge-red" style={{ marginRight: "auto" }}>
                {data.tickets.filter((t) => t.status === "جديدة").length}
              </span>
            )}
        </button>
      ))}
    </>
  );
  const empty = (text: string) => <div className="empty">{text}</div>;
  const stat = (label: string, value: ReactNode, Icon: any) => (
    <div className="stat-card" key={label} data-testid={`stat-${label}`}>
      <div className="stat-icon">
        <Icon size={19} />
      </div>
      <div>
        <div className="stat-num">{value}</div>
        <div className="stat-label">{label}</div>
      </div>
    </div>
  );
  const heading = (eyebrow: string, h: string, desc: string) => (
    <div className="page-heading">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h1>{h}</h1>
        <p>{desc}</p>
      </div>
      <div className="date-chip">
        <CalendarDays
          size={14}
          style={{ verticalAlign: "middle", marginLeft: 6 }}
        />
        {new Date().toLocaleDateString("ar-EG", {
          weekday: "long",
          day: "numeric",
          month: "long",
        })}
      </div>
    </div>
  );
  const panel = (h: string, children: ReactNode, action?: ReactNode) => (
    <section className="panel">
      <div className="panel-head">
        <h2>{h}</h2>
        {action}
      </div>
      {children}
    </section>
  );
  const subjectTiles = (list: Row[]) =>
    list.length ? (
      <div className="subject-list">
        {list.map((s, i) => (
          <button
            className="subject-tile"
            key={`${s.id}_${i}`}
            onClick={() => subjectContent(s.id)}
            data-testid={`subject-${s.id}`}
          >
            <span className="subject-symbol">
              <BookOpen size={16} />
            </span>
            <b>{s.name}</b>
            <small>
              {myContent.filter((c) => c.subjectId === s.id).length} مواد
              تعليمية
            </small>
          </button>
        ))}
      </div>
    ) : (
      empty("لا توجد مواد في هذا المسار حتى الآن.")
    );
  const contentCards = (list: Row[], admin = false) =>
    list.length ? (
      <div className="content-cards">
        {list.map((c) => (
          <article
            key={c.id}
            className="card content-card"
            data-testid={`content-${c.id}`}
          >
            <div className="panel-head">
              <span className="badge badge-blue">{typeLabel(c.type)}</span>
              {admin && (
                <button
                  className="btn btn-plain btn-small"
                  onClick={() => remove("content", c.id, "تم حذف المحتوى")}
                  aria-label="حذف المحتوى"
                  data-testid={`delete-content-${c.id}`}
                >
                  <Trash2 size={15} />
                </button>
              )}
            </div>
            <b>{c.title}</b>
            <p>{c.description || "مورد تعليمي ضمن مواد مسارك."}</p>
            <div className="inline">
              <span className="subject-tag">
                {data.tracks
                  .find((t) => t.id === c.trackId)
                  ?.subjects?.find((s: Row) => s.id === c.subjectId)?.name ||
                  "مادة"}
              </span>
              {c.url ? (
                <a
                  className="btn btn-secondary btn-small"
                  href={c.url}
                  target="_blank"
                  rel="noreferrer"
                  data-testid={`open-content-${c.id}`}
                >
                  <Video size={14} /> مشاهدة
                </a>
              ) : c.blob ? (
                <a
                  className="btn btn-secondary btn-small"
                  href={URL.createObjectURL(c.blob)}
                  download={c.title}
                  data-testid={`download-content-${c.id}`}
                >
                  <Download size={14} /> فتح الملف
                </a>
              ) : null}
            </div>
          </article>
        ))}
      </div>
    ) : (
      empty("لا يوجد محتوى تعليمي هنا بعد.")
    );
  const table = (headers: string[], rows: ReactNode[], emptyText: string) =>
    rows.length ? (
      <div className="table-wrap">
        <table className="table">
          <thead>
            <tr>
              {headers.map((h) => (
                <th key={h}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>{rows}</tbody>
        </table>
      </div>
    ) : (
      empty(emptyText)
    );
  let page: ReactNode;
  if (view === "overview" && user.role === "student") {
    const done = Math.min(
      100,
      myExams.length
        ? Math.round((myResults.length / myExams.length) * 100)
        : 0,
    );
    page = (
      <>
        {heading(
          "مساحة الطالب",
          "أهلاً، " + user.name.split(" ")[0],
          "خطوة صغيرة كل يوم تقرّبك من هدفك الدراسي.",
        )}
        <div className="welcome-banner">
          <div className="welcome-copy">
            <div className="eyebrow">مسارك لهذا العام</div>
            <h2>{track?.name || "لم يتم تحديد المسار"}</h2>
            <p>كل ما تحتاجه لمتابعة دراستك، في مكان واحد.</p>
          </div>
          <div className="welcome-side">
            التقدم في الامتحانات
            <br />
            <b>{done}٪</b> مكتمل
          </div>
        </div>
        <div className="stats-grid">
          {stat("المواد الدراسية", track?.subjects?.length || 0, BookOpen)}
          {stat("المحتوى التعليمي", myContent.length, FolderOpen)}
          {stat(
            "الامتحانات المنجزة",
            `${myResults.length} / ${myExams.length}`,
            Award,
          )}
          {stat(
            "متوسط النتائج",
            myResults.length
              ? `${Math.round(myResults.reduce((a, r) => a + r.score, 0) / myResults.length)}٪`
              : "—",
            ClipboardCheck,
          )}
        </div>
        <div className="columns">
          <div>
            {panel(
              "مواد مسارك",
              track
                ? subjectTiles(track.subjects)
                : empty("اختر مساراً دراسياً من إعدادات الحساب. <"),
            )}
            {panel(
              "أضيف مؤخراً",
              recentContent.length ? (
                <>
                  {recentContent.map((c) => (
                    <div className="list-row" key={c.id}>
                      <div className="subject-symbol">
                        <FileText size={15} />
                      </div>
                      <div className="row-content">
                        <b>{c.title}</b>
                        <small>
                          {typeLabel(c.type)} · {date(c.createdAt)}
                        </small>
                      </div>
                      <span className="row-trailing">
                        {
                          track?.subjects?.find(
                            (s: Row) => s.id === c.subjectId,
                          )?.name
                        }
                      </span>
                    </div>
                  ))}
                </>
              ) : (
                empty("سيظهر هنا كل محتوى جديد لمسارك.")
              ),
            )}
          </div>
          <div>
            {panel(
              "ملخص التقدم",
              <>
                <div
                  className="inline"
                  style={{
                    justifyContent: "space-between",
                    fontSize: 12,
                    marginBottom: 12,
                  }}
                >
                  <b>إنجاز الامتحانات</b>
                  <span className="eyebrow">{done}٪</span>
                </div>
                <div
                  style={{
                    height: 8,
                    background: "#edf2ef",
                    borderRadius: 8,
                    overflow: "hidden",
                  }}
                >
                  <div
                    style={{
                      height: "100%",
                      width: `${done}%`,
                      background: "var(--teal)",
                      borderRadius: 8,
                      transition: "width .3s",
                    }}
                  />
                </div>
                <p className="hint" style={{ marginTop: 12 }}>
                  أكملت {myResults.length} من أصل {myExams.length} امتحان متاح.
                </p>
                <button
                  className="btn btn-secondary btn-small"
                  onClick={() => go("exams")}
                  data-testid="button-go-exams"
                >
                  عرض الامتحانات <ChevronLeft size={14} />
                </button>
              </>,
            )}
            {panel(
              "إعلانات المنصة",
              notifs.length
                ? notifs
                    .slice(-3)
                    .reverse()
                    .map((n) => (
                      <div className="notice" key={n.id}>
                        <b>{n.title}</b>
                        <p>{n.message}</p>
                        <span className="hint">{date(n.createdAt)}</span>
                      </div>
                    ))
                : empty("لا توجد إعلانات جديدة."),
            )}
          </div>
        </div>
      </>
    );
  } else if (view === "overview") {
    const openCount = data.tickets.filter(
      (t) => t.status === "جديدة" || t.status === "قيد المراجعة",
    ).length;
    page = (
      <>
        {heading(
          "إدارة المنصة",
          "لوحة التحكم",
          "نظرة سريعة على سير العملية التعليمية وآخر المستجدات.",
        )}
        <div className="stats-grid">
          {stat(
            "إجمالي الطلاب",
            data.users.filter((u) => u.role === "student").length,
            Users,
          )}
          {stat("المسارات التعليمية", data.tracks.length, RouteIcon)}
          {stat("المحتوى المرفوع", data.content.length, FolderOpen)}
          {stat("طلبات تحتاج متابعة", openCount, Headset)}
        </div>
        <div className="columns">
          <div>
            {panel(
              "أحدث تذاكر الدعم",
              recentTickets.length
                ? recentTickets.map((t) => (
                    <div
                      className="ticket-item"
                      key={t.id}
                      data-testid={`ticket-summary-${t.id}`}
                    >
                      <b>{t.subject}</b>
                      <small>
                        {t.studentName} · {date(t.createdAt)}
                      </small>
                      <span className={`badge ${statusClass(t.status)}`}>
                        {t.status}
                      </span>
                    </div>
                  ))
                : empty("لا توجد تذاكر دعم بعد."),
              <button
                className="quiet-link"
                onClick={() => go("supportAdmin")}
                data-testid="link-all-tickets"
              >
                عرض الكل
              </button>,
            )}
            {panel(
              "المحتوى المضاف مؤخراً",
              recentContent.length
                ? recentContent.map((c) => (
                    <div className="list-row" key={c.id}>
                      <div className="subject-symbol">
                        <FileText size={15} />
                      </div>
                      <div className="row-content">
                        <b>{c.title}</b>
                        <small>
                          {data.tracks.find((t) => t.id === c.trackId)?.name ||
                            "مسار"}
                        </small>
                      </div>
                      <span className="badge badge-blue">
                        {typeLabel(c.type)}
                      </span>
                    </div>
                  ))
                : empty("لم تتم إضافة محتوى تعليمي بعد."),
            )}
          </div>
          <div>
            {panel(
              "المسارات الأكاديمية",
              data.tracks.length
                ? data.tracks.map((t) => (
                    <div className="list-row" key={t.id}>
                      <div className="subject-symbol">
                        <RouteIcon size={16} />
                      </div>
                      <div className="row-content">
                        <b>{t.name}</b>
                        <small>{t.subjects.length} مواد دراسية</small>
                      </div>
                      <span className="row-trailing">
                        <Users size={14} />
                      </span>
                    </div>
                  ))
                : empty("لا توجد مسارات مضافة."),
            )}
            {panel(
              "وصول سريع",
              <div style={{ display: "grid", gap: 9 }}>
                <button
                  className="btn btn-secondary"
                  onClick={() => go("students")}
                  data-testid="quick-students"
                >
                  <Users size={15} /> إدارة الطلاب
                </button>
                <button
                  className="btn btn-secondary"
                  onClick={() => go("content")}
                  data-testid="quick-content"
                >
                  <Plus size={15} /> إضافة محتوى تعليمي
                </button>
                <button
                  className="btn btn-secondary"
                  onClick={() => go("notices")}
                  data-testid="quick-notices"
                >
                  <Megaphone size={15} /> إرسال إعلان
                </button>
              </div>,
            )}
          </div>
        </div>
      </>
    );
  } else if (view === "subjects") {
    const selected = track?.subjects?.find((s: Row) => s.id === subjectPick);
    const subjectData = data.content.filter(
      (c) =>
        c.trackId === user.trackId &&
        (!subjectPick || c.subjectId === subjectPick),
    );
    page = (
      <>
        {heading(
          "رحلتك التعليمية",
          selected?.name || "موادي الدراسية",
          selected
            ? "المحتوى والموارد المخصصة لهذه المادة."
            : "اختر مادة للاطلاع على دروسها ومواردها.",
        )}
        {selected && (
          <button
            className="btn btn-secondary btn-small"
            style={{ marginBottom: 16 }}
            onClick={() => setSubjectPick(null)}
            data-testid="button-back-subjects"
          >
            <ChevronLeft size={14} /> جميع المواد
          </button>
        )}
        {selected
          ? contentCards(subjectData)
          : track
            ? subjectTiles(track.subjects)
            : empty("لم يتم تحديد مسار دراسي لحسابك.")}
        {selected &&
          subjectData.length === 0 &&
          empty("لا يوجد محتوى مدرج لهذه المادة حالياً.")}
      </>
    );
  } else if (view === "exams") {
    if (examRun) {
      const q = examRun.questions[examIdx],
        mins = Math.floor(timeLeft / 60),
        secs = timeLeft % 60;
      page = (
        <>
          {heading(
            "الامتحان الجاري",
            examRun.title,
            `السؤال ${examIdx + 1} من ${examRun.questions.length}`,
          )}
          <div className="panel">
            <div className="panel-head">
              <h2>السؤال {examIdx + 1}</h2>
              <span className="badge badge-amber">
                <Clock3 size={13} /> {mins}:{String(secs).padStart(2, "0")}
              </span>
            </div>
            <h3 style={{ fontSize: 18, margin: "20px 0" }}>{q.text}</h3>
            <div style={{ display: "grid", gap: 10 }}>
              {q.options.map((o: string, i: number) => (
                <label
                  className="option-row"
                  key={i}
                  style={{
                    display: "flex",
                    gap: 10,
                    alignItems: "center",
                    padding: 13,
                    border: "1px solid var(--line)",
                    borderRadius: 11,
                    cursor: "pointer",
                  }}
                >
                  <input
                    type="radio"
                    name="answer"
                    checked={answers[examIdx] === i}
                    onChange={() => setAnswers((a) => ({ ...a, [examIdx]: i }))}
                  />
                  {o}
                </label>
              ))}
            </div>
            <div
              className="inline"
              style={{ justifyContent: "space-between", marginTop: 24 }}
            >
              <button
                className="btn btn-secondary"
                disabled={examIdx === 0}
                onClick={() => setExamIdx((i) => i - 1)}
                data-testid="button-prev-question"
              >
                السابق
              </button>
              {examIdx === examRun.questions.length - 1 ? (
                <button
                  className="btn btn-primary"
                  onClick={() => void submitExam()}
                  data-testid="button-submit-exam"
                >
                  إنهاء وتسليم
                </button>
              ) : (
                <button
                  className="btn btn-primary"
                  onClick={() => setExamIdx((i) => i + 1)}
                  data-testid="button-next-question"
                >
                  السؤال التالي <ChevronLeft size={14} />
                </button>
              )}
            </div>
          </div>
        </>
      );
    } else {
      page = (
        <>
          {heading(
            "قياس التقدم",
            "الامتحانات والنتائج",
            "اختبر فهمك وراجع سجل نتائجك في أي وقت.",
          )}
          {panel(
            "الامتحانات المتاحة",
            myExams.length ? (
              <div className="content-cards">
                {myExams.map((ex) => (
                  <article
                    className="card content-card"
                    key={ex.id}
                    data-testid={`exam-card-${ex.id}`}
                  >
                    <div className="panel-head">
                      <span className="badge badge-amber">
                        <Clock3 size={12} /> {ex.duration} دقيقة
                      </span>
                      <span className="hint">{ex.questions.length} أسئلة</span>
                    </div>
                    <b>{ex.title}</b>
                    <p>اختبار قصير لمراجعة مفاهيم المسار.</p>
                    {myResults.some((r) => r.examId === ex.id) ? (
                      <span className="badge badge-green">
                        تم الحل ·{" "}
                        {myResults.find((r) => r.examId === ex.id)?.score}٪
                      </span>
                    ) : (
                      <button
                        className="btn btn-primary btn-small"
                        onClick={() => {
                          setExamRun(ex);
                          setExamIdx(0);
                          setAnswers({});
                          setTimeLeft(ex.duration * 60);
                        }}
                        data-testid={`start-exam-${ex.id}`}
                      >
                        بدء الامتحان <ArrowUpLeft size={14} />
                      </button>
                    )}
                  </article>
                ))}
              </div>
            ) : (
              empty("لا توجد امتحانات متاحة لمسارك حالياً.")
            ),
          )}
          {panel(
            "سجل النتائج",
            table(
              ["الامتحان", "النتيجة", "النسبة", "تاريخ الإكمال"],
              myResults.map((r) => (
                <tr key={r.id} data-testid={`result-${r.id}`}>
                  <td>{r.examTitle}</td>
                  <td>
                    {r.obtainedScore} / {r.totalScore}
                  </td>
                  <td>
                    <span
                      className={`badge ${r.score >= 50 ? "badge-green" : "badge-red"}`}
                    >
                      {r.score}٪
                    </span>
                  </td>
                  <td>{date(r.date)}</td>
                </tr>
              )),
              "ستظهر نتائجك بعد إكمال أول امتحان.",
            ),
          )}
        </>
      );
    }
  } else if (view === "support" || view === "supportAdmin") {
    page = (
      <>
        {heading(
          user.role === "admin" ? "خدمة الطلاب" : "نحن هنا للمساعدة",
          user.role === "admin" ? "فريق دعم المنصة" : "الدعم الفني",
          "تابع طلبات الدعم وتواصل مع فريق المنصة.",
        )}
        {user.role === "student" && (
          <div className="toolbar">
            <span className="hint">تذاكرك محفوظة ضمن حسابك.</span>
            <button
              className="btn btn-primary"
              onClick={() =>
                openModal("تذكرة دعم جديدة", (closeModal) => (
                  <TicketForm
                    tracks={data.tracks}
                    submit={createTicket}
                    close={closeModal}
                  />
                ))
              }
              data-testid="button-create-ticket"
            >
              <Plus size={15} /> إنشاء تذكرة جديدة
            </button>
          </div>
        )}
        {table(
          user.role === "admin"
            ? ["الطالب", "عنوان الطلب", "النوع", "الحالة", "التاريخ", "إجراء"]
            : [
                "رقم الطلب",
                "عنوان الطلب",
                "النوع",
                "الحالة",
                "التاريخ",
                "إجراء",
              ],
          myTickets.map((t) => (
            <tr key={t.id} data-testid={`ticket-row-${t.id}`}>
              <td>
                {user.role === "admin" ? t.studentName : `#${t.id.slice(-5)}`}
              </td>
              <td>{t.subject}</td>
              <td>{t.type}</td>
              <td>
                <span className={`badge ${statusClass(t.status)}`}>
                  {t.status}
                </span>
              </td>
              <td>{date(t.createdAt)}</td>
              <td>
                <div className="inline">
                  <button
                    className="btn btn-secondary btn-small"
                    onClick={() => openChat(t)}
                    data-testid={`open-ticket-${t.id}`}
                  >
                    <MessageCircle size={14} /> المحادثة
                  </button>
                  {user.role === "admin" && (
                    <select
                      aria-label="تحديث حالة التذكرة"
                      value={t.status}
                      onChange={async (e) => {
                        await put("tickets", { ...t, status: e.target.value });
                        await refresh();
                        flash("تم تحديث حالة التذكرة");
                      }}
                      data-testid={`ticket-status-${t.id}`}
                      style={{ width: 130, padding: "7px" }}
                    >
                      <option>جديدة</option>
                      <option>قيد المراجعة</option>
                      <option>تم الرد</option>
                      <option>مغلقة</option>
                    </select>
                  )}
                </div>
              </td>
            </tr>
          )),
          user.role === "admin"
            ? "لا توجد تذاكر واردة."
            : "لا توجد تذاكر حتى الآن.",
        )}
      </>
    );
  } else if (view === "students") {
    const students = data.users.filter(
      (u) =>
        u.role === "student" &&
        (!query ||
          u.name.includes(query) ||
          u.email.toLowerCase().includes(query.toLowerCase())),
    );
    page = (
      <>
        {heading(
          "إدارة المنصة",
          "إدارة الطلاب",
          "قائمة الطلاب المسجلين ومساراتهم الدراسية.",
        )}
        {data.users.filter((u) => u.role === "student").length ? (
          <div className="toolbar">
            <div className="search">
              <Search size={15} />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="ابحث باسم الطالب أو البريد"
                data-testid="input-search-students"
              />
            </div>
            <span className="badge badge-blue">
              {data.users.filter((u) => u.role === "student").length} طالب
            </span>
          </div>
        ) : null}
        {table(
          [
            "الطالب",
            "البريد الإلكتروني",
            "المسار الدراسي",
            "تاريخ الانضمام",
            "إجراء",
          ],
          students.map((s) => (
            <tr key={s.id} data-testid={`student-row-${s.id}`}>
              <td>
                <div className="inline">
                  <Avatar user={s} />
                  <b>{s.name}</b>
                </div>
              </td>
              <td>{s.email}</td>
              <td>
                {data.tracks.find((t) => t.id === s.trackId)?.name ||
                  "غير محدد"}
              </td>
              <td>{date(s.createdAt)}</td>
              <td>
                <button
                  className="btn btn-danger btn-small"
                  onClick={() =>
                    void remove("users", s.id, "تم حذف حساب الطالب")
                  }
                  data-testid={`delete-student-${s.id}`}
                >
                  <Trash2 size={13} /> حذف
                </button>
              </td>
            </tr>
          )),
          query ? "لا توجد نتائج مطابقة." : "لم يسجل أي طالب بعد.",
        )}
      </>
    );
  } else if (view === "tracks") {
    page = (
      <>
        {heading(
          "البنية الأكاديمية",
          "المسارات والمواد",
          "هيكل التخصصات والمواد التعليمية المعتمدة.",
        )}
        {
          <div className="content-cards">
            {data.tracks.map((t: Row) => (
              <article
                className="panel"
                key={t.id}
                data-testid={`track-${t.id}`}
              >
                <div className="panel-head">
                  <h2>{t.name}</h2>
                  <span className="badge badge-blue">
                    {t.subjects.length} مواد
                  </span>
                </div>
                <div style={{ display: "grid", gap: 8 }}>
                  {t.subjects.map((s: Row, i: number) => (
                    <div
                      key={`${s.id}_${i}`}
                      className="list-row"
                      style={{ padding: "9px 0" }}
                    >
                      <span className="subject-symbol">
                        <BookOpen size={14} />
                      </span>
                      <div className="row-content">
                        <b>{s.name}</b>
                        {s.isCommon && (
                          <span className="badge badge-green">مشتركة</span>
                        )}
                      </div>
                      <div className="inline" style={{ gap: 6 }}>
                        <button
                          className="btn btn-secondary btn-small"
                          title={`تعديل ${s.name}`}
                          aria-label={`تعديل ${s.name}`}
                          onClick={() =>
                            openModal("تعديل المادة", (closeModal) => (
                              <SubjectForm
                                tracks={data.tracks}
                                track={t}
                                subject={s}
                                save={(input) =>
                                  saveSubject(s.id, input, closeModal)
                                }
                                close={closeModal}
                              />
                            ))
                          }
                          data-testid={`edit-subject-${s.id}-${t.id}`}
                        >
                          <Pencil size={13} />
                        </button>
                        <button
                          className="btn btn-danger btn-small"
                          title={`حذف ${s.name}`}
                          aria-label={`حذف ${s.name}`}
                          onClick={() => void deleteSubject(s)}
                          data-testid={`delete-subject-${s.id}-${t.id}`}
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
                <button
                  className="btn btn-secondary btn-small"
                  style={{ marginTop: 14 }}
                  onClick={() =>
                    openModal("إضافة مادة للمسار", (closeModal) => (
                      <SubjectForm
                        tracks={data.tracks}
                        track={t}
                        save={(input) => saveSubject(null, input, closeModal)}
                        close={closeModal}
                      />
                    ))
                  }
                  data-testid={`add-subject-${t.id}`}
                >
                  <Plus size={14} /> إضافة مادة
                </button>
              </article>
            ))}
          </div>
        }
      </>
    );
  } else if (view === "content") {
    const list = data.content.filter(
      (c) => !query || c.title.toLowerCase().includes(query.toLowerCase()),
    );
    page = (
      <>
        {heading(
          "المكتبة التعليمية",
          "إدارة المحتوى التعليمي",
          "أضف الموارد التعليمية للمسارات والمواد.",
        )}
        <div className="toolbar">
          <div className="search">
            <Search size={15} />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="ابحث عن محتوى"
              data-testid="input-search-content"
            />
          </div>
          <button
            className="btn btn-primary"
            onClick={() =>
              openModal("إضافة محتوى تعليمي", (closeModal) => (
                <ContentForm
                  tracks={data.tracks}
                  save={saveContent}
                  close={closeModal}
                />
              ))
            }
            data-testid="button-add-content"
          >
            <Plus size={15} /> إضافة محتوى
          </button>
        </div>
        {contentCards(list, true)}
      </>
    );
  } else if (view === "examsAdmin") {
    page = (
      <>
        {heading(
          "التقييم الأكاديمي",
          "إدارة الامتحانات",
          "إنشاء الاختبارات ومتابعة إتاحتها للمسارات.",
        )}
        <div className="toolbar">
          <span className="hint">{data.exams.length} امتحان محفوظ</span>
          <button
            className="btn btn-primary"
            onClick={() =>
              openModal("إنشاء امتحان", (closeModal) => (
                <ExamForm
                  tracks={data.tracks}
                  save={saveExam}
                  close={closeModal}
                />
              ))
            }
            data-testid="button-add-exam"
          >
            <Plus size={15} /> إنشاء امتحان
          </button>
        </div>
        {data.exams.length ? (
          <div className="content-cards">
            {data.exams.map((ex) => (
              <article
                className="card content-card"
                key={ex.id}
                data-testid={`admin-exam-${ex.id}`}
              >
                <div className="panel-head">
                  <span className="badge badge-blue">
                    {data.tracks.find((t) => t.id === ex.trackId)?.name ||
                      "مسار"}
                  </span>
                  <span className="hint">{ex.duration} دقيقة</span>
                </div>
                <b>{ex.title}</b>
                <p>
                  {ex.questions.length} أسئلة · أُنشئ في {date(ex.createdAt)}
                </p>
                <button
                  className="btn btn-danger btn-small"
                  onClick={() => void remove("exams", ex.id, "تم حذف الامتحان")}
                  data-testid={`delete-exam-${ex.id}`}
                >
                  <Trash2 size={14} /> حذف الامتحان
                </button>
              </article>
            ))}
          </div>
        ) : (
          empty("لا توجد امتحانات منشأة. أنشئ أول اختبار للمسار.")
        )}
      </>
    );
  } else if (view === "notices") {
    page = (
      <>
        {heading(
          "التواصل مع الطلاب",
          "الإعلانات والإشعارات",
          "شارك التوجيهات والتحديثات مع جميع الطلاب أو مسار محدد.",
        )}
        <div className="toolbar">
          <span className="hint">{data.notifications.length} إعلانات</span>
          <button
            className="btn btn-primary"
            onClick={() =>
              openModal("إرسال إعلان للطلاب", (closeModal) => (
                <NoticeForm
                  tracks={data.tracks}
                  save={saveNotice}
                  close={closeModal}
                />
              ))
            }
            data-testid="button-create-notice"
          >
            <Plus size={15} /> إرسال إعلان
          </button>
        </div>
        {data.notifications.length
          ? data.notifications
              .slice()
              .reverse()
              .map((n) => (
                <section
                  className="panel"
                  key={n.id}
                  data-testid={`notice-${n.id}`}
                >
                  <div className="panel-head">
                    <h2>{n.title}</h2>
                    <span className="badge badge-blue">
                      {n.targetTrack === "all"
                        ? "جميع المسارات"
                        : data.tracks.find((t) => t.id === n.targetTrack)
                            ?.name || "مسار محدد"}
                    </span>
                  </div>
                  <p
                    style={{
                      fontSize: 12,
                      color: "var(--muted)",
                      lineHeight: 1.9,
                      margin: "0 0 10px",
                    }}
                  >
                    {n.message}
                  </p>
                  <span className="hint">{date(n.createdAt)}</span>
                </section>
              ))
          : empty("لا توجد إعلانات منشورة.")}
      </>
    );
  } else page = empty("الصفحة غير متاحة.");
  return (
    <div className="app" dir="rtl">
      <aside className={`sidebar ${mobile ? "open" : ""}`}>
        <div className="brand">
          <span className="brand-mark">
            <GraduationCap size={22} />
          </span>
          <span>
            رحلة البكالوريا<small>منصة التعلّم المدرسي</small>
          </span>
          <button
            className="mobile-toggle"
            style={{ marginRight: "auto" }}
            onClick={() => setMobile(false)}
            aria-label="إغلاق القائمة"
            data-testid="button-close-menu"
          >
            <X size={17} />
          </button>
        </div>
        <div className="profile">
          <Avatar user={user} />
          <div>
            <div className="profile-name" data-testid="text-user-name">
              {user.name}
            </div>
            <div className="profile-meta">
              {user.role === "admin" ? "مدير المنصة" : track?.name || "طالب"}
            </div>
          </div>
        </div>
        <nav className="nav">{allMenu()}</nav>
        <button className="logout" onClick={logout} data-testid="button-logout">
          <LogOut size={16} /> تسجيل الخروج
        </button>
      </aside>
      {mobile && (
        <div className="mobile-scrim show" onClick={() => setMobile(false)} />
      )}
      <main className="main">
        <header className="topbar">
          <div className="inline">
            <button
              className="mobile-toggle"
              onClick={() => setMobile(true)}
              aria-label="فتح القائمة"
              data-testid="button-open-menu"
            >
              <Menu size={18} />
            </button>
            <div className="top-title">{title[view] || "رحلة البكالوريا"}</div>
          </div>
          <div className="top-actions">
            <ThemeToggle theme={theme} onToggle={toggleTheme} />
            <button
              className="icon-button"
              aria-label="الإشعارات"
              onClick={() => setNoticeOpen((v) => !v)}
              data-testid="button-notifications"
            >
              <Bell size={17} />
              {notifs.length > 0 && <span className="notification-dot" />}
            </button>
            <span className="avatar" style={{ width: 34, height: 34 }}>
              <Avatar user={user} />
            </span>
          </div>
          {noticeOpen && (
            <div
              className="notifications-popover"
              style={{
                position: "absolute",
                left: 22,
                top: 65,
                width: "min(350px,calc(100vw - 32px))",
                background: "var(--paper)",
                border: "1px solid var(--line)",
                borderRadius: 14,
                boxShadow: "0 15px 45px var(--shadow)",
                padding: 16,
                zIndex: 12,
              }}
            >
              <div className="panel-head">
                <h2>إعلانات المنصة</h2>
                <button
                  className="quiet-link"
                  onClick={() => setNoticeOpen(false)}
                  data-testid="button-close-notifications"
                >
                  إغلاق
                </button>
              </div>
              {notifs.length
                ? notifs
                    .slice()
                    .reverse()
                    .slice(0, 5)
                    .map((n) => (
                      <div className="notice" key={n.id}>
                        <b>{n.title}</b>
                        <p>{n.message}</p>
                        <span className="hint">{date(n.createdAt)}</span>
                      </div>
                    ))
                : empty("لا توجد إعلانات جديدة.")}
            </div>
          )}
        </header>
        <section className="main-body">{page}</section>
      </main>
      {modal && (
        <div
          className="modal-backdrop"
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) close();
          }}
        >
          <div className="modal" role="dialog" aria-modal="true">
            <div className="modal-header">
              <h2>{modal.title}</h2>
              <button
                className="modal-close"
                onClick={close}
                aria-label="إغلاق"
                data-testid="button-close-modal"
              >
                <X size={16} />
              </button>
            </div>
            <div className="modal-body">{modal.body(close)}</div>
          </div>
        </div>
      )}
      {toast && (
        <div className="toast" role="status" data-testid="status-toast">
          {toast}
        </div>
      )}
    </div>
  );
}

function ThemeToggle({
  theme,
  onToggle,
}: {
  theme: AppTheme;
  onToggle: () => void;
}) {
  const isDark = theme === "dark";
  const label = isDark ? "تفعيل الوضع النهاري" : "تفعيل الوضع الليلي";
  return (
    <button
      type="button"
      className="icon-button theme-toggle"
      onClick={onToggle}
      aria-label={label}
      title={label}
      data-testid="button-toggle-theme"
    >
      {isDark ? <Sun size={17} /> : <Moon size={17} />}
    </button>
  );
}

function Avatar({ user }: { user: Row }) {
  const [src, setSrc] = useState("");
  useEffect(() => {
    if (
      typeof user.avatar === "string" &&
      user.avatar.startsWith("data:image/")
    ) {
      setSrc(user.avatar);
      return undefined;
    }
    if (user.avatar instanceof Blob) {
      const u = URL.createObjectURL(user.avatar);
      setSrc(u);
      return () => URL.revokeObjectURL(u);
    }
    setSrc("");
    return undefined;
  }, [user.avatar]);
  return (
    <span className="avatar" data-testid={`avatar-${user.id}`}>
      {src ? <img src={src} alt="" /> : user.name?.trim().charAt(0) || "ط"}
    </span>
  );
}
function FormField({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="field-group">
      <span>{label}</span>
      {children}
    </label>
  );
}
function TicketForm({
  tracks,
  submit,
  close,
}: {
  tracks: Row[];
  submit: (e: FormEvent<HTMLFormElement>, c: () => void) => void;
  close: () => void;
}) {
  return (
    <form className="modal-form" onSubmit={(e) => submit(e, close)}>
      <FormField label="عنوان الطلب">
        <input
          name="subject"
          className="field"
          required
          placeholder="اكتب عنواناً واضحاً"
          data-testid="input-ticket-subject"
        />
      </FormField>
      <FormField label="نوع الطلب">
        <select name="type" data-testid="select-ticket-type">
          <option>مشكلة تقنية</option>
          <option>مشكلة في المحتوى</option>
          <option>مشكلة في الامتحان</option>
          <option>استفسار عام</option>
        </select>
      </FormField>
      <FormField label="التفاصيل">
        <textarea
          name="message"
          required
          placeholder="اشرح لنا كيف يمكننا مساعدتك"
          data-testid="input-ticket-message"
        />
      </FormField>
      <div className="hint">
        فريق الدعم متاح لطلاب {tracks.length} مسارات دراسية.
      </div>
      <button
        className="btn btn-primary"
        type="submit"
        data-testid="button-submit-ticket"
      >
        <Send size={15} /> إرسال الطلب
      </button>
    </form>
  );
}
function Chat({
  ticket,
  data,
  user,
  send,
}: {
  ticket: Row;
  data: Record<StoreName, Row[]>;
  user: Row;
  send: (e: FormEvent<HTMLFormElement>, t: Row) => void;
}) {
  const messages = data.messages
    .filter((m) => m.ticketId === ticket.id)
    .sort((a, b) => +new Date(a.createdAt) - +new Date(b.createdAt));
  return (
    <div className="chat">
      <div className="chat-messages" data-testid={`chat-messages-${ticket.id}`}>
        {messages.length ? (
          messages.map((m) => (
            <div
              className={`chat-message ${m.senderRole === user.role ? "mine" : ""}`}
              key={m.id}
              data-testid={`message-${m.id}`}
            >
              <b>{m.senderName}</b>
              <div>{m.text}</div>
              <small>{date(m.createdAt)}</small>
            </div>
          ))
        ) : (
          <div className="empty">لا توجد رسائل بعد.</div>
        )}
      </div>
      <form className="chat-compose" onSubmit={(e) => send(e, ticket)}>
        <input
          className="field"
          name="text"
          required
          placeholder="اكتب رسالتك هنا..."
          data-testid="input-chat-message"
        />
        <button
          className="btn btn-primary"
          type="submit"
          aria-label="إرسال الرسالة"
          data-testid="button-send-message"
        >
          <Send size={15} />
        </button>
      </form>
    </div>
  );
}
function ContentForm({
  tracks,
  save,
  close,
}: {
  tracks: Row[];
  save: (e: FormEvent<HTMLFormElement>, c: () => void) => void;
  close: () => void;
}) {
  const [tid, setTid] = useState(tracks[0]?.id || "");
  const selected = tracks.find((t) => t.id === tid);
  return (
    <form className="modal-form" onSubmit={(e) => save(e, close)}>
      <FormField label="عنوان المحتوى">
        <input
          name="title"
          className="field"
          required
          data-testid="input-content-title"
        />
      </FormField>
      <FormField label="نوع المحتوى">
        <select name="type" data-testid="select-content-type">
          <option value="lesson">درس نصي</option>
          <option value="pdf">ملف PDF أو صورة</option>
          <option value="video">رابط فيديو</option>
          <option value="note">ملخص</option>
        </select>
      </FormField>
      <FormField label="المسار">
        <select
          name="trackId"
          value={tid}
          onChange={(e) => setTid(e.target.value)}
          required
          data-testid="select-content-track"
        >
          {tracks.map((t) => (
            <option value={t.id} key={t.id}>
              {t.name}
            </option>
          ))}
        </select>
      </FormField>
      <FormField label="المادة">
        <select name="subjectId" required data-testid="select-content-subject">
          {(selected?.subjects || []).map((s: Row, i: number) => (
            <option key={`${s.id}_${i}`} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>
      </FormField>
      <FormField label="وصف مختصر">
        <textarea name="description" data-testid="input-content-description" />
      </FormField>
      <FormField label="ملف مرفق (اختياري)">
        <input
          className="field"
          name="file"
          type="file"
          data-testid="input-content-file"
        />
      </FormField>
      <FormField label="رابط فيديو (اختياري)">
        <input
          className="field"
          name="url"
          type="url"
          placeholder="https://"
          data-testid="input-content-url"
        />
      </FormField>
      <button
        className="btn btn-primary"
        type="submit"
        data-testid="button-save-content"
      >
        حفظ المحتوى
      </button>
    </form>
  );
}
function ExamForm({
  tracks,
  save,
  close,
}: {
  tracks: Row[];
  save: (e: FormEvent<HTMLFormElement>, c: () => void) => void;
  close: () => void;
}) {
  const [questionIds, setQuestionIds] = useState([0]);
  const [nextQuestionId, setNextQuestionId] = useState(1);

  return (
    <form className="modal-form" onSubmit={(e) => save(e, close)}>
      <FormField label="عنوان الامتحان">
        <input
          name="title"
          className="field"
          required
          data-testid="input-exam-title"
        />
      </FormField>
      <div className="inline">
        <FormField label="المدة بالدقائق">
          <input
            name="duration"
            className="field"
            type="number"
            min="1"
            defaultValue="30"
            required
            data-testid="input-exam-duration"
          />
        </FormField>
        <FormField label="المسار">
          <select name="trackId" required data-testid="select-exam-track">
            {tracks.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </select>
        </FormField>
      </div>
      <div className="form-stack">
        {questionIds.map((questionId, index) => (
          <section
            className="panel"
            style={{ margin: 0, padding: 14 }}
            key={questionId}
            data-testid={`exam-question-${index}`}
          >
            <div className="panel-head">
              <div className="eyebrow" style={{ marginBottom: 10 }}>
                السؤال {index + 1}
              </div>
              {questionIds.length > 1 && (
                <button
                  type="button"
                  className="btn btn-plain btn-small"
                  onClick={() =>
                    setQuestionIds((current) =>
                      current.filter((id) => id !== questionId),
                    )
                  }
                  aria-label={`حذف السؤال ${index + 1}`}
                >
                  حذف السؤال
                </button>
              )}
            </div>
            <FormField label="نص السؤال">
              <input
                className="field"
                name="questionText[]"
                required
                data-testid={
                  index === 0
                    ? "input-exam-question"
                    : `input-exam-question-${index}`
                }
              />
            </FormField>
            <div className="inline" style={{ marginTop: 10 }}>
              <FormField label="الدرجة">
                <input
                  className="field"
                  name="questionPoints[]"
                  type="number"
                  min="1"
                  step="1"
                  defaultValue="1"
                  required
                  data-testid={`input-exam-points-${index}`}
                />
              </FormField>
              <FormField label="رقم الإجابة الصحيحة">
                <input
                  className="field"
                  name="correctIndex[]"
                  type="number"
                  min="0"
                  step="1"
                  defaultValue="0"
                  required
                  data-testid={
                    index === 0
                      ? "input-exam-correct"
                      : `input-exam-correct-${index}`
                  }
                />
              </FormField>
            </div>
            <FormField label="الخيارات — افصل بينها بفاصلة">
              <input
                className="field"
                name="options[]"
                required
                placeholder="الخيار الأول, الخيار الثاني"
                data-testid={
                  index === 0
                    ? "input-exam-options"
                    : `input-exam-options-${index}`
                }
              />
            </FormField>
            <div className="hint">
              يبدأ ترقيم الخيارات من الصفر. مثال: 0 للإجابة الأولى.
            </div>
          </section>
        ))}
        <button
          type="button"
          className="btn btn-secondary"
          onClick={() => {
            setQuestionIds((current) => [...current, nextQuestionId]);
            setNextQuestionId((current) => current + 1);
          }}
          data-testid="button-add-exam-question"
        >
          <Plus size={15} /> إضافة سؤال
        </button>
      </div>
      <button
        className="btn btn-primary"
        type="submit"
        data-testid="button-save-exam"
      >
        إنشاء الامتحان
      </button>
    </form>
  );
}
function NoticeForm({
  tracks,
  save,
  close,
}: {
  tracks: Row[];
  save: (e: FormEvent<HTMLFormElement>, c: () => void) => void;
  close: () => void;
}) {
  return (
    <form className="modal-form" onSubmit={(e) => save(e, close)}>
      <FormField label="عنوان الإعلان">
        <input
          className="field"
          name="title"
          required
          data-testid="input-notice-title"
        />
      </FormField>
      <FormField label="نص الإعلان">
        <textarea name="message" required data-testid="input-notice-message" />
      </FormField>
      <FormField label="الفئة المستهدفة">
        <select
          name="targetTrack"
          defaultValue="all"
          data-testid="select-notice-track"
        >
          <option value="all">جميع المسارات</option>
          {tracks.map((t) => (
            <option key={t.id} value={t.id}>
              {t.name}
            </option>
          ))}
        </select>
      </FormField>
      <button
        className="btn btn-primary"
        type="submit"
        data-testid="button-send-notice"
      >
        <Send size={15} /> نشر الإعلان
      </button>
    </form>
  );
}
function SubjectForm({
  tracks,
  track,
  subject,
  save,
  close,
}: {
  tracks: Row[];
  track: Row;
  subject?: Row;
  save: (input: {
    name: string;
    trackIds: string[];
    isCommon: boolean;
  }) => Promise<void>;
  close: () => void;
}) {
  const assignedTrackIds = subject?.isCommon
    ? tracks.map((item) => item.id)
    : tracks
        .filter((item) =>
          item.subjects.some((candidate: Row) => candidate.id === subject?.id),
        )
        .map((item) => item.id);
  const [selectedTrackIds, setSelectedTrackIds] =
    useState<string[]>(assignedTrackIds.length ? assignedTrackIds : [track.id]);
  const [isCommon, setIsCommon] = useState(Boolean(subject?.isCommon));
  const [formError, setFormError] = useState("");

  return (
    <form
      className="modal-form"
      onSubmit={(e) => {
        e.preventDefault();
        const f = new FormData(e.currentTarget);
        const name = String(f.get("name")).trim();
        if (!isCommon && selectedTrackIds.length === 0) {
          setFormError("اختر مسارًا واحدًا على الأقل.");
          return;
        }
        setFormError("");
        void save({
          name,
          trackIds: selectedTrackIds,
          isCommon,
        });
      }}
    >
      <p className="hint" style={{ margin: 0 }}>
        {subject ? "تعديل بيانات المادة والمسارات التي تظهر فيها." : track.name}
      </p>
      <FormField label="اسم المادة">
        <input
          className="field"
          name="name"
          required
          defaultValue={subject?.name || ""}
          data-testid="input-subject-name"
        />
      </FormField>
      <FormField label="تظهر في المسارات">
        <label className="inline" style={{ justifyContent: "flex-start" }}>
          <input
            type="checkbox"
            checked={isCommon}
            onChange={(event) => setIsCommon(event.target.checked)}
            data-testid="checkbox-subject-common"
          />
          مادة مشتركة تظهر في جميع المسارات
        </label>
        <div style={{ display: "grid", gap: 8, marginTop: 10 }}>
          {tracks.map((item) => (
            <label
              className="inline"
              style={{ justifyContent: "flex-start" }}
              key={item.id}
            >
              <input
                type="checkbox"
                name="trackIds"
                value={item.id}
                checked={isCommon || selectedTrackIds.includes(item.id)}
                disabled={isCommon}
                onChange={(event) =>
                  setSelectedTrackIds((current) =>
                    event.target.checked
                      ? [...current, item.id]
                      : current.filter((id) => id !== item.id),
                  )
                }
              />
              {item.name}
            </label>
          ))}
        </div>
      </FormField>
      {formError && (
        <p className="hint" role="alert">
          {formError}
        </p>
      )}
      <div className="inline">
        <button
          className="btn btn-secondary"
          type="button"
          onClick={close}
          data-testid="button-cancel-subject"
        >
          إلغاء
        </button>
        <button
          className="btn btn-primary"
          type="submit"
          data-testid="button-save-subject"
        >
          {subject ? "حفظ التعديلات" : "إضافة المادة"}
        </button>
      </div>
    </form>
  );
}

export default App;
