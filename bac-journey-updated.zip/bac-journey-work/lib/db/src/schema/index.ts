import {
  boolean,
  index,
  integer,
  pgTable,
  primaryKey,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const bacUsers = pgTable(
  "bac_users",
  {
    id: text("id").primaryKey(),
    name: text("name").notNull(),
    email: text("email").notNull().unique(),
    passwordHash: text("password_hash").notNull(),
    role: text("role").notNull().default("student"),
    trackId: text("track_id"),
    avatar: text("avatar"),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [index("bac_users_role_idx").on(table.role)],
);

export const bacSessions = pgTable(
  "bac_sessions",
  {
    tokenHash: text("token_hash").primaryKey(),
    userId: text("user_id")
      .notNull()
      .references(() => bacUsers.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [index("bac_sessions_user_idx").on(table.userId)],
);

export const bacTracks = pgTable(
  "bac_tracks",
  {
    id: text("id").primaryKey(),
    name: text("name").notNull(),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [index("bac_tracks_sort_idx").on(table.sortOrder)],
);

export const bacSubjects = pgTable(
  "bac_subjects",
  {
    id: text("id").primaryKey(),
    name: text("name").notNull(),
    isCommon: boolean("is_common").notNull().default(false),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [index("bac_subjects_name_idx").on(table.name)],
);

export const bacTrackSubjects = pgTable(
  "bac_track_subjects",
  {
    trackId: text("track_id")
      .notNull()
      .references(() => bacTracks.id, { onDelete: "cascade" }),
    subjectId: text("subject_id")
      .notNull()
      .references(() => bacSubjects.id, { onDelete: "cascade" }),
  },
  (table) => [
    primaryKey({
      name: "bac_track_subjects_pk",
      columns: [table.trackId, table.subjectId],
    }),
    index("bac_track_subjects_subject_idx").on(table.subjectId),
  ],
);